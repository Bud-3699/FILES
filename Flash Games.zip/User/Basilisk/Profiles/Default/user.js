user_pref("browser.cache.disk.parent_directory", "C:\\Users\\Bud\\Desktop\\FLASH\\User\\Basilisk\\Profiles\\Default");
user_pref("browser.download.lastDir", "C:\\Users\\Bud\\Desktop\\FLASH\\Downloads");
user_pref("browser.shell.checkDefaultBrowser", false);
user_pref("browser.taskbar.lists.enabled", false);
